#!/bin/bash

# Adjust Timezone
echo "America/Chicago" | sudo tee /etc/timezone
dpkg-reconfigure --frontend noninteractive tzdata

# Update OS
apt-get update

## Required Packages
apt-get install mysql-server mysql-client build-essential libmysqlclient-dev libsnmp-dev libcurl4-gnutls-dev fping nmap traceroute libxml2-dev libxml2 libpcre3-dev git -y

exit 0
