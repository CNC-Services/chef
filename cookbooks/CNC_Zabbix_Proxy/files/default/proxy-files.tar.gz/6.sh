#!/bin/bash

#Import variables from secure file
export $(cat /home/cnc-zab/secure_files/version1.txt | xargs)

echo DBPassword=$cnczabMySQLPassword >> /usr/local/etc/zabbix_proxy.conf

exit 0
