#!/bin/bash

# Installer variables
ZABUSER="cnc-zab"
DOWNDIR=/home/$ZABUSER/tmp
VERSION="3.4.4"

# Install Source
cd $DOWNDIR/zabbix-$VERSION
./configure --enable-proxy --enable-agent --with-mysql --with-net-snmp --with-libcurl --with-libxml2 --with-openssl
make install

exit 0
